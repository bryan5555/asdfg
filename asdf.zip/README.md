## 개요
리버티 스킨을 [imitated seed](https://github.com/gdl-blue/imitated-seed-2) 엔진에서 사용할 수 있게 포팅함. [미리보기](https://liawiki.glitch.me/)

PR 환영합니다.

## 원작
[liberty-skin](https://github.com/librewiki/liberty-skin) → [theseed-skin-liberty](https://github.com/namu-theseed/theseed-skin-liberty)
